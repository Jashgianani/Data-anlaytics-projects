import streamlit as st
import pickle


# Set the background image and text color
background_image = """
<style>
[data-testid="stAppViewContainer"] > .main {
    background-image: url("https://images.unsplash.com/photo-1633158829585-23ba8f7c8caf?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D");
    background-size: 100vw 100vh;
    background-position: center;  
    background-repeat: no-repeat;
    color: #000000; /* Set text color to black */
}
</style>
"""

st.markdown(background_image, unsafe_allow_html=True)


# Load the pre-trained model
with open('model.pkl', 'rb') as file:
    model = pickle.load(file)

# Function to make predictions
def predict_subscription(age, job, marital, education, campaign, housing, loan, previous,month_int,balance_group):
    # Make predictions using the loaded model
    prediction = model.predict([[age, job, marital, education, campaign, housing, loan, previous,month_int,balance_group]])
    return prediction

# Define the Streamlit app
def main():
    # Set the title of the app
    st.title('Customer Subscription Prediction')

    # Add some instructions for the user
    st.write('Please enter the required information to predict customer subscription.')

    # Add input fields for user data
    age = st.slider('Age', min_value=10, step=10, max_value=100)
    job = st.selectbox('Job', ['entrepreneur', 'technician', 'retired', 'services', 'blue-collar',
                               'admin.', 'self-employed', 'management', 'student', 'housemaid',
                               'unemployed', 'other'])
    marital = st.selectbox('Marital Status', ['single', 'married', 'divorced'])
    education = st.selectbox('Education', ['tertiary', 'secondary', 'primary'])
    campaign = st.number_input('campaign', min_value=0)
    housing = st.selectbox('Housing Loan', ['no', 'yes'])
    loan = st.selectbox('Personal Loan', ['no', 'yes'])
    previous = st.number_input('Contacts performed', min_value=0, step=1, max_value=30)
    month_int=st.number_input('Month',min_value=1,step=1,max_value=12)
    balance_group=st.selectbox('Account Balance',['0', '0-1000', '1000-5000', '>5000'])

    # When the user clicks the predict button
    if st.button('Predict'):
        # Convert categorical variables to numerical encoding
        job_encoded = ['entrepreneur', 'technician', 'retired', 'services', 'blue-collar',
                       'admin.', 'self-employed', 'management', 'student', 'housemaid',
                       'unemployed', 'other'].index(job)
        marital_encoded = ['single', 'married', 'divorced'].index(marital)
        education_encoded = ['tertiary', 'secondary', 'primary'].index(education)
        housing_encoded = ['no', 'yes'].index(housing)
        loan_encoded = ['no', 'yes'].index(loan)
        balance_group_encoded=['0', '0-1000', '1000-5000', '>5000'].index(balance_group)

        # Make prediction
        prediction = predict_subscription(age, job_encoded, marital_encoded, education_encoded, campaign, housing_encoded, loan_encoded, previous,month_int,balance_group_encoded)

        # Display the prediction to the user
        if prediction[0] == 1:
            st.write('The customer is likely to take the loan.')
        else:
            st.write('The customer is unlikely to take the loan.')

if __name__ == "__main__":
    main()
